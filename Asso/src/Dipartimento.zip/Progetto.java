public class Progetto {
	
	private String name;
	private float budget;
	
	public Progetto(String a, float x) {
		name = a;
		budget = x;
	}
}
