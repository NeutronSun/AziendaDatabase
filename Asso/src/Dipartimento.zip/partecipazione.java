public class partecipazione {
	private String nameProj;
	private int idWorker;
}
